
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/quran_repository.dart';
import '../models.dart';
import '../widgets/ayah_tile.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _q = TextEditingController();
  int? _sura;
  int? _juz;
  int? _page;
  List<Ayah> _results = [];

  @override
  Widget build(BuildContext context) {
    final repo = context.read<QuranRepository>();
    final surahs = repo.getSurahList();

    void runSearch() {
      setState(() {
        _results = repo.search(_q.text, suraNo: _sura, jozz: _juz, page: _page);
      });
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              TextField(
                controller: _q,
                textDirection: TextDirection.rtl,
                decoration: const InputDecoration(
                  hintText: "ابحث بالنص...",
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (_) => runSearch(),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.end,
                children: [
                  DropdownButton<int?>(
                    value: _sura,
                    hint: const Text("السورة"),
                    items: [
                      const DropdownMenuItem(value: null, child: Text("الكل")),
                      ...surahs.map((s) => DropdownMenuItem(value: s.no, child: Text("${s.nameAr} (${s.no})", textDirection: TextDirection.rtl)))
                    ],
                    onChanged: (v) { setState(() => _sura = v); runSearch(); },
                  ),
                  DropdownButton<int?>(
                    value: _juz,
                    hint: const Text("الجزء"),
                    items: [
                      const DropdownMenuItem(value: null, child: Text("الكل")),
                      ...List.generate(repo.maxJuz, (i) => DropdownMenuItem(value: i+1, child: Text("${i+1}")))
                    ],
                    onChanged: (v) { setState(() => _juz = v); runSearch(); },
                  ),
                  SizedBox(
                    width: 120,
                    child: TextField(
                      decoration: const InputDecoration(
                        labelText: "الصفحة",
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      onChanged: (t) {
                        final v = int.tryParse(t);
                        setState(() => _page = v);
                        runSearch();
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const Divider(height: 0),
        Expanded(
          child: _results.isEmpty
            ? const Center(child: Text("اكتب نص البحث أو اختر فلتر"))
            : ListView.builder(
                itemCount: _results.length,
                itemBuilder: (c, i) => AyahTile(ayah: _results[i]),
              ),
        )
      ],
    );
  }
}
