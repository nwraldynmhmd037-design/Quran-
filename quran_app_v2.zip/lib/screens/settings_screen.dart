
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text("المظهر", textDirection: TextDirection.rtl, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        SegmentedButton<ThemeMode>(
          segments: const [
            ButtonSegment(value: ThemeMode.light, label: Text("فاتح")),
            ButtonSegment(value: ThemeMode.dark, label: Text("داكن")),
            ButtonSegment(value: ThemeMode.system, label: Text("النظام")),
          ],
          selected: <ThemeMode>{app.themeMode},
          onSelectionChanged: (s) => app.setTheme(s.first),
        ),
        const SizedBox(height: 24),
        Text("حجم الخط", textDirection: TextDirection.rtl, style: Theme.of(context).textTheme.titleLarge),
        Slider(
          value: app.fontScale,
          min: 0.8, max: 1.6, divisions: 8,
          label: app.fontScale.toStringAsFixed(1),
          onChanged: (v) => app.setFontScale(v),
        ),
        const SizedBox(height: 24),
        if (app.lastReadSurah != null)
          ListTile(
            title: const Text("متابعة القراءة", textDirection: TextDirection.rtl),
            subtitle: Text("السورة ${app.lastReadSurah} الآية ${app.lastReadAyah}", textDirection: TextDirection.rtl),
            trailing: const Icon(Icons.play_arrow),
            onTap: () => Navigator.of(context).pushNamed('/continue'),
          ),
      ],
    );
  }
}
