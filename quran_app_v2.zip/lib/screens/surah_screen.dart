
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/quran_repository.dart';
import '../state/app_state.dart';
import '../models.dart';
import '../widgets/ayah_tile.dart';

class SurahScreen extends StatefulWidget {
  const SurahScreen({super.key});

  @override
  State<SurahScreen> createState() => _SurahScreenState();
}

class _SurahScreenState extends State<SurahScreen> {
  int? highlightedAyah;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final repo = context.read<QuranRepository>();
    final surahAyat = repo.ayatInSurah(app.currentSurah);
    final surah = repo.getSurahList().firstWhere((s) => s.no == app.currentSurah);

    return GestureDetector(
      onHorizontalDragEnd: (d) {
        if (d.primaryVelocity == null) return;
        if (d.primaryVelocity! < 0) { // swipe left -> next surah
          final next = app.currentSurah < 114 ? app.currentSurah + 1 : 1;
          app.setCurrentSurah(next);
        } else if (d.primaryVelocity! > 0) { // swipe right -> previous
          final prev = app.currentSurah > 1 ? app.currentSurah - 1 : 114;
          app.setCurrentSurah(prev);
        }
      },
      child: ListView(
        children: [
          // Elegant header
          Container(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primaryContainer,
                  Theme.of(context).colorScheme.surface,
                ],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  surah.nameAr,
                  textDirection: TextDirection.rtl,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  "عدد الآيات: ${surah.ayahCount}",
                  textDirection: TextDirection.rtl,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (surah.no != 9) // no basmala for At-Tawbah
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Center(
                child: Text(
                  "بِسْمِ ٱللّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
                  textDirection: TextDirection.rtl,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
            ),
          ...surahAyat.map((a) => AyahTile(
            ayah: a,
            highlighted: highlightedAyah == a.ayaNo,
            onLongPress: () {
              setState(() { highlightedAyah = a.ayaNo; });
              app.toggleFav(a);
              app.markLastRead(a.suraNo, a.ayaNo);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(app.isFav(a) ? "أُضيفت للمفضلة" : "أُزيلت من المفضلة"),
                  duration: const Duration(seconds: 1),
                ),
              );
            },
            onTapFav: () {
              app.toggleFav(a);
              app.markLastRead(a.suraNo, a.ayaNo);
            },
          ))
        ],
      ),
    );
  }
}
