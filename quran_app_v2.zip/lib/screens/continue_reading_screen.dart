
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../data/quran_repository.dart';
import '../widgets/ayah_tile.dart';

class ContinueReadingScreen extends StatelessWidget {
  const ContinueReadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final repo = context.read<QuranRepository>();
    final sura = app.lastReadSurah ?? app.currentSurah;
    final ayahNo = app.lastReadAyah ?? 1;
    final list = repo.ayatInSurah(sura);
    return ListView(
      children: [
        const SizedBox(height: 12),
        ...list.map((a) => AyahTile(ayah: a, highlighted: a.ayaNo == ayahNo)),
      ],
    );
  }
}
