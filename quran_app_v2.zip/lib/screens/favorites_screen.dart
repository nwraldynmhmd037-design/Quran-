
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../models.dart';
import '../widgets/ayah_tile.dart';
import '../data/quran_repository.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final repo = context.read<QuranRepository>();

    // Build favorites by scanning through all ayat quickly
    final favs = <Ayah>[];
    for (final s in repo.getSurahList()) {
      for (final a in repo.ayatInSurah(s.no)) {
        if (app.isFav(a)) favs.add(a);
      }
    }

    if (favs.isEmpty) {
      return const Center(child: Text("لا توجد آيات مفضلة بعد"));
    }
    return ListView.builder(
      itemCount: favs.length,
      itemBuilder: (c, i) {
        final a = favs[i];
        return AyahTile(ayah: a, onTapFav: () => app.toggleFav(a));
      },
    );
  }
}
