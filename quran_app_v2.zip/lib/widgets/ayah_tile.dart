
import 'package:flutter/material.dart';
import '../models.dart';

class AyahTile extends StatelessWidget {
  final Ayah ayah;
  final bool highlighted;
  final VoidCallback? onLongPress;
  final VoidCallback? onTapFav;
  const AyahTile({super.key, required this.ayah, this.highlighted=false, this.onLongPress, this.onTapFav});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      decoration: BoxDecoration(
        color: highlighted ? theme.colorScheme.secondaryContainer : theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.dividerColor.withOpacity(.2)),
        boxShadow: [
          BoxShadow(
            blurRadius: 8,
            spreadRadius: 0,
            offset: const Offset(0,2),
            color: Colors.black.withOpacity(0.06),
          )
        ]
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 16,
                child: Text("${ayah.ayaNo}", textDirection: TextDirection.ltr),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  ayah.text,
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: theme.textTheme.titleMedium,
                ),
              ),
              if (onTapFav != null) 
                IconButton(
                  tooltip: "إضافة للمفضلة",
                  icon: const Icon(Icons.star_border),
                  onPressed: onTapFav,
                )
            ],
          ),
        ),
      ),
    );
  }
}
