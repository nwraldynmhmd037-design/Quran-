
class Ayah {
  final int id;
  final int suraNo;
  final String suraNameAr;
  final String suraNameEn;
  final int ayaNo;
  final String text;
  final String textEmlaey;
  final int page;
  final int jozz;

  Ayah({
    required this.id,
    required this.suraNo,
    required this.suraNameAr,
    required this.suraNameEn,
    required this.ayaNo,
    required this.text,
    required this.textEmlaey,
    required this.page,
    required this.jozz,
  });

  factory Ayah.fromMap(Map<String, dynamic> m) => Ayah(
        id: m['id'] as int,
        suraNo: m['sura_no'] as int,
        suraNameAr: m['sura_name_ar'] as String,
        suraNameEn: m['sura_name_en'] as String,
        ayaNo: m['aya_no'] as int,
        text: m['aya_text'] as String,
        textEmlaey: m['aya_text_emlaey'] as String? ?? '',
        page: m['page'] as int,
        jozz: m['jozz'] as int,
      );
}

class SurahSummary {
  final int no;
  final String nameAr;
  final String nameEn;
  final int ayahCount;

  SurahSummary({required this.no, required this.nameAr, required this.nameEn, required this.ayahCount});
}
