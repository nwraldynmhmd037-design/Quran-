
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models.dart';

class QuranRepository {
  List<Ayah> _all = [];
  final Map<int, List<Ayah>> _bySurah = {};
  final Map<int, SurahSummary> _surahMeta = {};

  Future<void> load() async {
    if (_all.isNotEmpty) return;
    final raw = await rootBundle.loadString('assets/hafsData_v2-0.json');
    final List<dynamic> data = json.decode(raw);
    _all = data.map((e) => Ayah.fromMap(Map<String, dynamic>.from(e))).toList();

    // Index by surah
    for (final a in _all) {
      _bySurah.putIfAbsent(a.suraNo, () => []).add(a);
    }

    // Surah meta
    _bySurah.forEach((no, list) {
      _surahMeta[no] = SurahSummary(
        no: no,
        nameAr: list.first.suraNameAr,
        nameEn: list.first.suraNameEn,
        ayahCount: list.length,
      );
    });
  }

  List<SurahSummary> getSurahList() {
    final list = _surahMeta.values.toList()
      ..sort((a, b) => a.no.compareTo(b.no));
    return list;
  }

  List<Ayah> ayatInSurah(int suraNo) {
    final l = _bySurah[suraNo] ?? [];
    l.sort((a, b) => a.ayaNo.compareTo(b.ayaNo));
    return l;
  }

  /// Simple contains search in emlaey (no diacritics) & raw text, with optional filters
  List<Ayah> search(String query, {int? suraNo, int? jozz, int? page}) {
    final q = query.trim();
    if (q.isEmpty) return [];
    return _all.where((a) {
      if (suraNo != null && a.suraNo != suraNo) return false;
      if (jozz != null && a.jozz != jozz) return false;
      if (page != null && a.page != page) return false;
      final haystack = (a.textEmlaey + " " + a.text);
      return haystack.contains(q);
    }).toList();
  }

  int get maxPage => _all.isEmpty ? 604 : _all.map((e) => e.page).reduce((a, b) => a > b ? a : b);
  int get maxJuz => _all.isEmpty ? 30 : _all.map((e) => e.jozz).reduce((a, b) => a > b ? a : b);
}
