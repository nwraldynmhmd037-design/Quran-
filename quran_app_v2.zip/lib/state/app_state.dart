
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models.dart';
import '../data/quran_repository.dart';

class AppState extends ChangeNotifier {
  final QuranRepository repo;
  ThemeMode themeMode = ThemeMode.system;
  double fontScale = 1.0;
  int currentSurah = 1;
  int? lastReadSurah;
  int? lastReadAyah;
  final Set<int> _favoriteIds = {};

  AppState(this.repo);

  Future<void> init() async {
    await repo.load();
    final sp = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values[sp.getInt('themeMode') ?? 0];
    fontScale = sp.getDouble('fontScale') ?? 1.1;
    currentSurah = sp.getInt('currentSurah') ?? 1;
    lastReadSurah = sp.getInt('lastSurah');
    lastReadAyah = sp.getInt('lastAyah');
    _favoriteIds.addAll(sp.getStringList('favIds')?.map(int.parse) ?? []);
    notifyListeners();
  }

  Future<void> setTheme(ThemeMode mode) async {
    themeMode = mode;
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('themeMode', mode.index);
    notifyListeners();
  }

  Future<void> setFontScale(double v) async {
    fontScale = v;
    final sp = await SharedPreferences.getInstance();
    await sp.setDouble('fontScale', v);
    notifyListeners();
  }

  Future<void> setCurrentSurah(int no) async {
    currentSurah = no;
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('currentSurah', no);
    notifyListeners();
  }

  Future<void> markLastRead(int sura, int ayah) async {
    lastReadSurah = sura;
    lastReadAyah = ayah;
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('lastSurah', sura);
    await sp.setInt('lastAyah', ayah);
    notifyListeners();
  }

  bool isFav(Ayah a) => _favoriteIds.contains(a.id);

  Future<void> toggleFav(Ayah a) async {
    if (_favoriteIds.contains(a.id)) {
      _favoriteIds.remove(a.id);
    } else {
      _favoriteIds.add(a.id);
    }
    final sp = await SharedPreferences.getInstance();
    await sp.setStringList('favIds', _favoriteIds.map((e) => e.toString()).toList());
    notifyListeners();
  }

  List<Ayah> favorites() {
    final all = repo.search(""); // returns empty; we need from all
    // Workaround: access repository private? We'll recompute by current surah list union:
    // Instead, ask repo for all ayat via surah loop
    final favs = <Ayah>[];
    for (final s in repo.getSurahList()) {
      for (final a in repo.ayatInSurah(s.no)) {
        if (_favoriteIds.contains(a.id)) favs.add(a);
      }
    }
    return favs;
  }
}
