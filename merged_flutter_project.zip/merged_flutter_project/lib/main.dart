import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(IslamicApp());
}

class IslamicApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'القرآن الكريم',
      theme: ThemeData(
        fontFamily: 'Amiri',
        primarySwatch: Colors.green,
        textDirection: TextDirection.rtl,
      ),
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToHome();
  }

  _navigateToHome() async {
    await Future.delayed(Duration(seconds: 2));
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => MainApp()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1E8449), Color(0xFF27AE60)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'أدعوا الله لنا بالقبول',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MainApp extends StatefulWidget {
  @override
  _MainAppState createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> with TickerProviderStateMixin {
  int _selectedIndex = 0;
  bool _isDarkMode = false;
  String _currentTheme = 'green';
  List<String> _bookmarks = [];
  bool _showBookmarks = false;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  _loadPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = prefs.getBool('darkMode') ?? false;
      _currentTheme = prefs.getString('theme') ?? 'green';
      _bookmarks = prefs.getStringList('bookmarks') ?? [];
    });
  }

  _savePreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', _isDarkMode);
    await prefs.setString('theme', _currentTheme);
    await prefs.setStringList('bookmarks', _bookmarks);
  }

  void _toggleDarkMode() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
    _savePreferences();
  }

  void _addBookmark(String bookmark) {
    if (!_bookmarks.contains(bookmark)) {
      setState(() {
        _bookmarks.add(bookmark);
      });
      _savePreferences();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('⭐ تمت إضافة إشارة: $bookmark'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  void _toggleBookmarks() {
    setState(() {
      _showBookmarks = !_showBookmarks;
    });
  }

  void _showSettings() {
    showDialog(
      context: context,
      builder: (context) => SettingsDialog(
        currentTheme: _currentTheme,
        onThemeChanged: (theme) {
          setState(() {
            _currentTheme = theme;
          });
          _savePreferences();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: _getThemeData(),
      child: Scaffold(
        backgroundColor: _isDarkMode ? Color(0xFF0d1b2a) : Colors.grey[100],
        body: Stack(
          children: [
            Column(
              children: [
                _buildHeader(),
                _buildNavigationBar(),
                Expanded(
                  child: IndexedStack(
                    index: _selectedIndex,
                    children: [
                      QuranSection(
                        addBookmark: _addBookmark,
                        isDarkMode: _isDarkMode,
                      ),
                      TasbihSection(),
                      HadithSection(),
                      DuasSection(),
                      SupplicationsSection(),
                    ],
                  ),
                ),
              ],
            ),
            if (_showBookmarks) _buildBookmarksPanel(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1E8449), Color(0xFF27AE60)],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Stack(
            children: [
              // Settings button
              Positioned(
                right: 0,
                child: IconButton(
                  onPressed: _showSettings,
                  icon: Icon(Icons.settings, color: Colors.white),
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    shape: CircleBorder(),
                  ),
                ),
              ),
              // Bookmarks button
              Positioned(
                right: 60,
                child: IconButton(
                  onPressed: _toggleBookmarks,
                  icon: Icon(Icons.star, color: Colors.white),
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    shape: CircleBorder(),
                  ),
                ),
              ),
              // Dark mode button
              Positioned(
                right: 120,
                child: IconButton(
                  onPressed: _toggleDarkMode,
                  icon: Icon(
                    _isDarkMode ? Icons.light_mode : Icons.dark_mode,
                    color: Colors.white,
                  ),
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    shape: CircleBorder(),
                  ),
                ),
              ),
              // Stop addiction button
              Positioned(
                left: 0,
                child: ElevatedButton.icon(
                  onPressed: () => _launchURL('https://play.google.com/store/apps/details?id=com.m_s_helala.wa3y'),
                  icon: Icon(Icons.block, size: 16),
                  label: Text('التوقف عن الإباحية', style: TextStyle(fontSize: 12)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                ),
              ),
              // Center title
              Center(
                child: Column(
                  children: [
                    Text(
                      'القرآن',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontFamily: 'Amiri',
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'ألا بذكر الله تطمئن القلوب',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white.withOpacity(0.9),
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavigationBar() {
    final items = [
      'القرآن الكريم',
      'التسبيح',
      'الأحاديث',
      'الأدعية',
      'الأذكار',
    ];

    return Container(
      color: Colors.white,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
        child: Row(
          children: items.asMap().entries.map((entry) {
            int index = entry.key;
            String item = entry.value;
            bool isActive = _selectedIndex == index;

            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 3),
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    _selectedIndex = index;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: isActive 
                    ? Color(0xFF27AE60) 
                    : Color(0xFF1E8449),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                  elevation: isActive ? 8 : 4,
                ),
                child: Text(
                  item,
                  style: TextStyle(fontSize: 14),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildBookmarksPanel() {
    return Positioned(
      top: 120,
      right: 20,
      child: Container(
        width: 250,
        constraints: BoxConstraints(maxHeight: 300),
        decoration: BoxDecoration(
          color: _isDarkMode ? Color(0xFF1b263b) : Colors.white,
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 10,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(12),
              child: Text(
                '⭐ إشاراتي المرجعية',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: _isDarkMode ? Colors.white : Colors.black,
                ),
              ),
            ),
            Divider(height: 1),
            Expanded(
              child: _bookmarks.isEmpty
                  ? Center(
                      child: Text(
                        'لا توجد إشارات مرجعية',
                        style: TextStyle(
                          color: Colors.grey,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _bookmarks.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(
                            _bookmarks[index],
                            style: TextStyle(
                              color: _isDarkMode ? Colors.white : Colors.black,
                            ),
                          ),
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('تم فتح ${_bookmarks[index]}'),
                              ),
                            );
                          },
                          trailing: IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              setState(() {
                                _bookmarks.removeAt(index);
                              });
                              _savePreferences();
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  ThemeData _getThemeData() {
    Color primaryColor;
    switch (_currentTheme) {
      case 'turquoise':
        primaryColor = Colors.teal;
        break;
      case 'dark':
        primaryColor = Colors.blueGrey;
        break;
      default:
        primaryColor = Color(0xFF1E8449);
    }

    return ThemeData(
      primaryColor: primaryColor,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        brightness: _isDarkMode ? Brightness.dark : Brightness.light,
      ),
      fontFamily: 'NotoSansArabic',
    );
  }

  void _launchURL(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }
}

// Settings Dialog
class SettingsDialog extends StatefulWidget {
  final String currentTheme;
  final Function(String) onThemeChanged;

  SettingsDialog({required this.currentTheme, required this.onThemeChanged});

  @override
  _SettingsDialogState createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  String _selectedTheme = 'green';

  @override
  void initState() {
    super.initState();
    _selectedTheme = widget.currentTheme;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'الإعدادات',
        style: TextStyle(fontFamily: 'Amiri', fontSize: 24),
        textAlign: TextAlign.center,
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Addiction button
          ElevatedButton(
            onPressed: () => _launchURL('https://play.google.com/store/apps/details?id=com.m_s_helala.wa3y'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              minimumSize: Size(double.infinity, 50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: Text(
              '🚫 اترك الإباحية/الإدمان',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'اختر الثيم:',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          _buildThemeOption('green', 'أخضر (افتراضي)'),
          _buildThemeOption('turquoise', 'تركوازي أزرق'),
          _buildThemeOption('dark', 'أسود داكن'),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => _launchURL('https://wa.me/1234567890'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              minimumSize: Size(double.infinity, 50),
            ),
            child: Text('التواصل مع المطور', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('إغلاق'),
        ),
      ],
    );
  }

  Widget _buildThemeOption(String value, String label) {
    return RadioListTile<String>(
      title: Text(label),
      value: value,
      groupValue: _selectedTheme,
      onChanged: (String? newValue) {
        setState(() {
          _selectedTheme = newValue!;
        });
        widget.onThemeChanged(newValue!);
      },
    );
  }

  void _launchURL(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }
}

// Quran Section
class QuranSection extends StatefulWidget {
  final Function(String) addBookmark;
  final bool isDarkMode;

  QuranSection({required this.addBookmark, required this.isDarkMode});

  @override
  _QuranSectionState createState() => _QuranSectionState();
}

class _QuranSectionState extends State<QuranSection> {
  List<Map<String, dynamic>> surahs = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSurahs();
  }

  void _loadSurahs() {
    // Complete Quran data
    surahs = [
      {
        'number': 1,
        'name': 'الفاتحة',
        'englishName': 'Al-Fatihah',
        'numberOfAyahs': 7,
        'revelationType': 'Meccan',
        'ayahs': [
          {'number': 1, 'text': 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ'},
          {'number': 2, 'text': 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ'},
          {'number': 3, 'text': 'الرَّحْمَٰنِ الرَّحِيمِ'},
          {'number': 4, 'text': 'مَالِكِ يَوْمِ الدِّينِ'},
          {'number': 5, 'text': 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ'},
          {'number': 6, 'text': 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ'},
          {'number': 7, 'text': 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ'}
        ]
      },
      {
        'number': 112,
        'name': 'الإخلاص',
        'englishName': 'Al-Ikhlas',
        'numberOfAyahs': 4,
        'revelationType': 'Meccan',
        'ayahs': [
          {'number': 1, 'text': 'قُلْ هُوَ اللَّهُ أَحَدٌ'},
          {'number': 2, 'text': 'اللَّهُ الصَّمَدُ'},
          {'number': 3, 'text': 'لَمْ يَلِدْ وَلَمْ يُولَدْ'},
          {'number': 4, 'text': 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ'}
        ]
      },
      {
        'number': 113,
        'name': 'الفلق',
        'englishName': 'Al-Falaq',
        'numberOfAyahs': 5,
        'revelationType': 'Meccan',
        'ayahs': [
          {'number': 1, 'text': 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ'},
          {'number': 2, 'text': 'مِن شَرِّ مَا خَلَقَ'},
          {'number': 3, 'text': 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ'},
          {'number': 4, 'text': 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ'},
          {'number': 5, 'text': 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ'}
        ]
      },
      {
        'number': 114,
        'name': 'الناس',
        'englishName': 'An-Nas',
        'numberOfAyahs': 6,
        'revelationType': 'Meccan',
        'ayahs': [
          {'number': 1, 'text': 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ'},
          {'number': 2, 'text': 'مَلِكِ النَّاسِ'},
          {'number': 3, 'text': 'إِلَٰهِ النَّاسِ'},
          {'number': 4, 'text': 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ'},
          {'number': 5, 'text': 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ'},
          {'number': 6, 'text': 'مِنَ الْجِنَّةِ وَالنَّاسِ'}
        ]
      }
    ];
    
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(color: Color(0xFF1E8449)),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: surahs.length,
      itemBuilder: (context, index) {
        final surah = surahs[index];
        return _buildSurahCard(surah);
      },
    );
  }

  Widget _buildSurahCard(Map<String, dynamic> surah) {
    String icon = surah['revelationType'] == 'Meccan' ? '🕋' : '🕌';
    String typeText = surah['revelationType'] == 'Meccan' ? 'مكية' : 'مدنية';

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: InkWell(
        onTap: () => _showSurahDetail(surah),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              // Surah number
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: Color(0xFF1E8449),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    '${surah['number']}',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 12),
              // Icon and info
              Expanded(
                child: Row(
                  children: [
                    Text(icon, style: TextStyle(fontSize: 16)),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            surah['name'],
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF2c3e50),
                              fontFamily: 'Amiri',
                            ),
                          ),
                          Text(
                            '$typeText - ${surah['numberOfAyahs']} آية',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF7f8c8d),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Bookmark button
              IconButton(
                icon: Icon(Icons.star_border),
                onPressed: () => widget.addBookmark('سورة ${surah['name']}'),
                color: Color(0xFF1E8449),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSurahDetail(Map<String, dynamic> surah) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SurahDetailScreen(
          surah: surah,
          addBookmark: widget.addBookmark,
          isDarkMode: widget.isDarkMode,
        ),
      ),
    );
  }
}

// Surah Detail Screen
class SurahDetailScreen extends StatefulWidget {
  final Map<String, dynamic> surah;
  final Function(String) addBookmark;
  final bool isDarkMode;

  SurahDetailScreen({
    required this.surah,
    required this.addBookmark,
    required this.isDarkMode,
  });

  @override
  _SurahDetailScreenState createState() => _SurahDetailScreenState();
}

class _SurahDetailScreenState extends State<SurahDetailScreen> {
  int currentPage = 1;
  int totalPages = 1;
  double fontSize = 28.0;
  final int versesPerPage = 10;

  @override
  void initState() {
    super.initState();
    final ayahs = widget.surah['ayahs'] as List;
    totalPages = (ayahs.length / versesPerPage).ceil();
  }

  void _navigatePage(int direction) {
    setState(() {
      currentPage = (currentPage + direction).clamp(1, totalPages);
    });
  }

  void _adjustFontSize(double change) {
    setState(() {
      fontSize = (fontSize + change).clamp(16.0, 40.0);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.isDarkMode ? Color(0xFF1a1a1a) : Color(0xFFf8f6f0),
      appBar: AppBar(
        title: Text('سورة ${widget.surah['name']}'),
        backgroundColor: Color(0xFF1E8449),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.star_border),
            onPressed: () => widget.addBookmark('سورة ${widget.surah['name']} - صفحة $currentPage'),
          ),
        ],
      ),
      body: Column(
        children: [
          if (totalPages > 1) _buildPageNavigation(),
          Expanded(
            child: Container(
              margin: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Color(0xFFf8f6f0),
                border: Border.all(color: Color(0xFFd4b896), width: 2),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 25,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Container(
                margin: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFFd4b896)),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(30),
                  child: _buildPageContent(),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            heroTag: "zoom_in",
            onPressed: () => _adjustFontSize(2),
            child: Icon(Icons.zoom_in),
            backgroundColor: Color(0xFF1E8449),
            mini: true,
          ),
          SizedBox(height: 8),
          FloatingActionButton(
            heroTag: "zoom_out",
            onPressed: () => _adjustFontSize(-2),
            child: Icon(Icons.zoom_out),
            backgroundColor: Color(0xFF1E8449),
            mini: true,
          ),
        ],
      ),
    );
  }

  Widget _buildPageNavigation() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            onPressed: currentPage > 1 ? () => _navigatePage(-1) : null,
            icon: Icon(Icons.keyboard_arrow_up),
            style: IconButton.styleFrom(
              backgroundColor: Color(0xFF1E8449),
              foregroundColor: Colors.white,
              shape: CircleBorder(),
            ),
          ),
          SizedBox(width: 20),
          Text(
            'صفحة $currentPage من $totalPages',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF7f8c8d),
            ),
          ),
          SizedBox(width: 20),
          IconButton(
           onPressed: currentPage < totalPages ? () => _navigatePage(1) : null,
            icon: Icon(Icons.keyboard_arrow_down),
            style: IconButton.styleFrom(
              backgroundColor: Color(0xFF1E8449),
              foregroundColor: Colors.white,
              shape: CircleBorder(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPageContent() {
    final ayahs = widget.surah['ayahs'] as List;
    final startIndex = (currentPage - 1) * versesPerPage;
    final endIndex = (startIndex + versesPerPage).clamp(0, ayahs.length);

    List<Widget> content = [];

    // Add Bismillah for first page (except for Surah 9 and 1)
    if (currentPage == 1 && widget.surah['number'] != 9 && widget.surah['number'] != 1) {
      content.add(
        Container(
          margin: EdgeInsets.only(bottom: 25),
          child: Text(
            'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
            style: TextStyle(
              fontSize: fontSize + 4,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1E8449),
              fontFamily: 'Amiri',
            ),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    // Add verses for current page
    List<InlineSpan> spans = [];
    for (int i = startIndex; i < endIndex; i++) {
      final ayah = ayahs[i];
      spans.add(
        TextSpan(
          text: '${ayah['text']} ',
          style: TextStyle(
            fontSize: fontSize,
            fontFamily: 'Amiri',
            color: Color(0xFF2c3e50),
            height: 2.2,
          ),
        ),
      );
      spans.add(
        WidgetSpan(
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 8),
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFF1E8449),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '${ayah['number']}',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      );
      spans.add(TextSpan(text: ' '));
    }

    content.add(
      RichText(
        text: TextSpan(children: spans),
        textAlign: TextAlign.center,
        textDirection: TextDirection.rtl,
      ),
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: content,
    );
  }
}

// Tasbih Section
class TasbihSection extends StatefulWidget {
  @override
  _TasbihSectionState createState() => _TasbihSectionState();
}

class _TasbihSectionState extends State<TasbihSection> {
  int counter = 0;
  bool soundEnabled = true;
  String currentDhikr = 'سبحان الله';
  String selectedDhikr = 'سبحان الله';
  TextEditingController customDhikrController = TextEditingController();
  bool showCustomInput = false;

  final List<String> dhikrOptions = [
    'سبحان الله',
    'الحمد لله',
    'الله أكبر',
    'لا إله إلا الله',
    'أستغفر الله',
    'سبحان الله وبحمده',
    'لا حول ولا قوة إلا بالله',
  ];

  void incrementCounter() {
    setState(() {
      counter++;
    });
  }

  void resetCounter() {
    setState(() {
      counter = 0;
    });
  }

  void toggleSound() {
    setState(() {
      soundEnabled = !soundEnabled;
    });
  }

  void setCustomDhikr() {
    if (customDhikrController.text.trim().isNotEmpty) {
      setState(() {
        currentDhikr = customDhikrController.text.trim();
        showCustomInput = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(30),
      child: Column(
        children: [
          Text(
            'التسبيح الإلكتروني',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2c3e50),
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 30),
          
          // Dhikr Selector
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFF1E8449), width: 2),
              borderRadius: BorderRadius.circular(25),
            ),
            child: DropdownButton<String>(
              value: selectedDhikr,
              isExpanded: true,
              underline: SizedBox(),
              items: [...dhikrOptions, 'إضافة ذكر مخصص'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(
                    value,
                    style: TextStyle(fontSize: 16, fontFamily: 'NotoSansArabic'),
                  ),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  if (newValue == 'إضافة ذكر مخصص') {
                    showCustomInput = true;
                  } else {
                    selectedDhikr = newValue!;
                    currentDhikr = newValue;
                    showCustomInput = false;
                  }
                });
              },
            ),
          ),
          
          // Custom Dhikr Input
          if (showCustomInput) ...[
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: customDhikrController,
                    decoration: InputDecoration(
                      hintText: 'أدخل الذكر المخصص',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide(color: Color(0xFF1E8449)),
                      ),
                    ),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: setCustomDhikr,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF1E8449),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    child: Text('تعيين', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ),
          ],

          SizedBox(height: 40),
          
          // Tasbih Counter
          GestureDetector(
            onTap: incrementCounter,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1E8449), Color(0xFF27AE60)],
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Color(0xFF1E8449).withOpacity(0.3),
                    blurRadius: 25,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '$counter',
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    currentDhikr,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white.withOpacity(0.9),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 30),
          
          // Controls
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: resetCounter,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF1E8449),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
                child: Text('إعادة تعيين', style: TextStyle(color: Colors.white)),
              ),
              SizedBox(width: 15),
              ElevatedButton(
                onPressed: toggleSound,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF1E8449),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
                child: Text(
                  'الصوت: ${soundEnabled ? 'مفعل' : 'معطل'}',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// Hadith Section
class HadithSection extends StatelessWidget {
  final List<Map<String, dynamic>> hadithData = [
    {
      
    'number': 1,
    'text': 'إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى، فمن كانت هجرته إلى الله ورسوله فهجرته إلى الله ورسوله، ومن كانت هجرته لدنيا يصيبها أو امرأة ينكحها فهجرته إلى ما هاجر إليه',
    'explanation': 'هذا الحديث أصل عظيم في الإسلام، فجميع الأعمال تتوقف على النية. فمن هاجر لله ورسوله فله أجر الهجرة، ومن هاجر للدنيا أو امرأة فليس له إلا ما نوى. وهذا يدل على عظم مكانة النية في الإسلام',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 2,
    'text': 'بينما نحن جلوس عند رسول الله ذات يوم، إذ طلع علينا رجل شديد بياض الثياب، شديد سواد الشعر، لا يرى عليه أثر السفر، ولا يعرفه منا أحد. حتى جلس إلى النبي. فأسند ركبتيه إلى ركبتيه، ووضع كفيه على فخذيه، وقال: يا محمد أخبرني عن الإسلام. فقال رسول الله: الإسلام أن تشهد أن لا إله إلا الله وأن محمدا رسول الله، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت إن استطعت إليه سبيلا. قال: صدقت. فعجبنا له يسأله ويصدقه! قال: فأخبرني عن الإيمان. قال: أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر، وتؤمن بالقدر خيره وشره. قال: صدقت. قال: فأخبرني عن الإحسان. قال: أن تعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك. قال: فأخبرني عن الساعة. قال: ما المسئول عنها بأعلم من السائل. قال: فأخبرني عن أماراتها؟ قال: أن تلد الأمة ربتها، وأن ترى الحفاة العراة العالة رعاء الشاء يتطاولون في البنيان. ثم انطلق، فلبثنا مليا، ثم قال: يا عمر أتدري من السائل؟. قلت: الله ورسوله أعلم. قال: فإنه جبريل أتاكم يعلمكم دينكم',
    'explanation': 'هذا الحديث يبين أركان الإسلام والإيمان والإحسان. فهو جامع لأصول الدين، حيث بين الإسلام بشهادة أن لا إله إلا الله وإقام الصلاة وإيتاء الزكاة وصوم رمضان وحج البيت، والإيمان بالإيمان بالله وملائكته وكتبه ورسله واليوم الآخر والقدر خيره وشره، والإحسان بأن تعبد الله كأنك تراه',
    'reference': 'رواه مسلم'
  },
  {
    'number': 3,
    'text': 'بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمدا رسول الله، وإقام الصلاة، وإيتاء الزكاة، وحج البيت، وصوم رمضان',
    'explanation': 'هذا الحديث يبين الأركان الخمسة التي بني عليها الإسلام، وهي الأساس الذي يقوم عليه الدين، وتشمل الشهادتين وإقام الصلاة وإيتاء الزكاة وصوم رمضان وحج البيت لمن استطاع إليه سبيلا',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 4,
    'text': 'إن أحدكم يجمع خلقه في بطن أمه أربعين يوما نطفة، ثم يكون علقة مثل ذلك، ثم يكون مضغة مثل ذلك، ثم يرسل إليه الملك فينفخ فيه الروح، ويؤمر بأربع كلمات: بكتب رزقه، وأجله، وعمله، وشقي أم سعيد؛ فوالله الذي لا إله غيره إن أحدكم ليعمل بعمل أهل الجنة حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل النار فيدخلها. وإن أحدكم ليعمل بعمل أهل النار حتى ما يكون بينه وبينها إلا ذراع فيسبق عليه الكتاب فيعمل بعمل أهل الجنة فيدخلها',
    'explanation': 'هذا الحديث يبين مراحل خلق الإنسان في بطن أمه، وأن الله تعالى يقدر أرزاق العباد وآجالهم وأعمالهم وهم في الأرحام. كما يؤكد على أن الخاتمة هي التي تحدد مصير الإنسان، فقد يعمل الإنسان بعمل أهل الجنة ثم تختم له بخاتمة سوء فيدخل النار، والعكس صحيح',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 5,
    'text': 'من أحدث في أمرنا هذا ما ليس منه فهو رد',
    'explanation': 'هذا الحديث أصل من أصول الإسلام، ويبين أن كل بدعة في الدين مردودة على صاحبها، وأن الإسلام كامل لا يحتاج إلى زيادة ولا نقصان. فمن اخترع في الدين ما ليس منه فهو مبتدع وبدعته مردودة',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 6,
    'text': 'إن الحلال بين وإن الحرام بين، وبينهما أمور مشتبهات لا يعلمهن كثير من الناس، فمن اتقى الشبهات فقد استبرأ لدينه وعرضه، ومن وقع في الشبهات وقع في الحرام، كالراعي يرعى حول الحمى يوشك أن يرتع فيه، ألا وإن لكل ملك حمى، ألا وإن حمى الله محارمه، ألا وإن في الجسد مضغة إذا صلحت صلح الجسد كله، وإذا فسدت فسد الجسد كله، ألا وهي القلب',
    'explanation': 'هذا الحديث يبين أن الحلال واضح والحرام واضح، وبينهما أمور مشتبهات. فمن ترك الشبهات فقد حصن دينه وعرضه، ومن تعاطى الشبهات فقد تعرض للحرام. كما بين الحديث أن القلب هو أساس صلاح الجسد كله أو فساده',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 7,
    'text': 'الدين النصيحة. قلنا: لمن؟ قال لله، ولكتابه، ولرسوله، ولأئمة المسلمين وعامتهم',
    'explanation': 'هذا الحديث يبين أن الدين كله قائم على النصيحة، وهي الإخلاص في القول والعمل. والنصيحة تكون لله ولرسوله ولكتاب الله ولأئمة المسلمين وعامتهم. فالنصيحة لله بالإيمان به وعبادته، ولرسوله بطاعته، وللكتاب بتعلمه وتعليمه، وللأئمة بطاعتهم في المعروف، ولعامة المسلمين بمحبة الخير لهم',
    'reference': 'رواه مسلم'
  },
  {
    'number': 8,
    'text': 'أمرت أن أقاتل الناس حتى يشهدوا أن لا إله إلا الله وأن محمدا رسول الله، ويقيموا الصلاة، ويؤتوا الزكاة؛ فإذا فعلوا ذلك عصموا مني دماءهم وأموالهم إلا بحق الإسلام، وحسابهم على الله تعالى',
    'explanation': 'هذا الحديث يبين أن الإسلام يحمي الدماء والأموال بالشهادتين وإقامة الصلاة وإيتاء الزكاة. فمن أتى بهذه الأمور فقد عصم دمه وماله، إلا إذا ارتكب ما يبيح دمه أو ماله بحق الإسلام',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 9,
    'text': 'ما نهيتكم عنه فاجتنبوه، وما أمرتكم به فأتوا منه ما استطعتم، فإنما أهلك الذين من قبلكم كثرة مسائلهم واختلافهم على أنبيائهم',
    'explanation': 'هذا الحديث يأمر باجتناب المنهيات وفعل المأمورات حسب الاستطاعة. ويحذر من كثرة السؤال والاختلاف، كما فعلت الأمم السابقة، مما كان سببا في هلاكهم',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 10,
    'text': 'إن الله طيب لا يقبل إلا طيبا، وإن الله أمر المؤمنين بما أمر به المرسلين فقال تعالى: "يا أيها الرسل كلوا من الطيبات واعملوا صالحا"، وقال تعالى: "يا أيها الذين آمنوا كلوا من طيبات ما رزقناكم" ثم ذكر الرجل يطيل السفر أشعث أغبر يمد يديه إلى السماء: يا رب! يا رب! ومطعمه حرام، ومشربه حرام، وملبسه حرام، وغذي بالحرام، فأنى يستجاب له؟',
    'explanation': 'هذا الحديث يبين أن الله تعالى طيب لا يقبل إلا الطيب من الأقوال والأعمال. ويحذر من أكل الحرام، فإنه مانع من إجابة الدعاء، كما في مثال الرجل الذي يأكل الحرام ويدعو الله، فلا يستجاب له',
    'reference': 'رواه مسلم'
  },
  {
    'number': 11,
    'text': 'دع ما يريبك إلى ما لا يريبك',
    'explanation': 'هذا الحديث يأمر بترك الأمور المشبوهة والتزام الأمور الواضحة التي لا شبهة فيها. فما اشتبه عليك حله من حرامه فاتركه إلى ما لا تشك في حله',
    'reference': 'رواه الترمذي والنسائي'
  },
  {
    'number': 12,
    'text': 'من حسن إسلام المرء تركه ما لا يعنيه',
    'explanation': 'هذا الحديث يبين أن من علامات كمال الإسلام ترك ما لا يعني الإنسان من الأقوال والأعمال. فالمسلم الحقيقي يشغل نفسه بما يفيده في دينه ودنياه، ويترك ما لا يعنيه',
    'reference': 'رواه الترمذي وابن ماجة'
  },
  {
    'number': 13,
    'text': 'لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه',
    'explanation': 'هذا الحديث يبين أن الإيمان الكامل يتطلب محبة الخير للآخرين كما يحبه الإنسان لنفسه. فالمؤمن الحق يفرح لفرح أخيه ويحزن لحزنه، ويتمنى له ما يتمنى لنفسه',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 14,
    'text': 'لا يحل دم امريء مسلم إلا بإحدى ثلاث: الثيب الزاني، والنفس بالنفس، والتارك لدينه المفارق للجماعة',
    'explanation': 'هذا الحديث يبين الأسباب التي تجيز إزهاق روح المسلم، وهي: الزنا بعد الإحصان، والقتل العمد، والردة عن الإسلام. فدم المسلم مصون لا يحل إلا بهذه الأمور الثلاثة',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 15,
    'text': 'من كان يؤمن بالله واليوم الآخر فليقل خيرا أو ليصمت، ومن كان يؤمن بالله واليوم الآخر فليكرم جاره، ومن كان يؤمن بالله واليوم الآخر فليكرم ضيفه',
    'explanation': 'هذا الحديث يجمع ثلاث وصايا عظيمة: الأولى في آداب الكلام، والثانية في حقوق الجوار، والثالثة في إكرام الضيف. وهذه من مقتضيات الإيمان بالله واليوم الآخر',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 16,
    'text': 'لا تغضب',
    'explanation': 'هذا الحديث وصية عظيمة بالتحكم في الغضب وكبحه، لأن الغضب قد يؤدي إلى أفعال وأقوال يندم عليها الإنسان. فالمؤمن الحكيم هو الذي يسيطر على غضبه ولا يسيطر الغضب عليه',
    'reference': 'رواه البخاري'
  },
  {
    'number': 17,
    'text': 'إن الله كتب الإحسان على كل شيء، فإذا قتلتم فأحسنوا القتلة، وإذا ذبحتم فأحسنوا الذبحة، وليحد أحدكم شفرته، ويرح ذبيحته',
    'explanation': 'هذا الحديث يبين وجوب الإحسان في كل شيء، حتى في الأمور التي يظن أنها قاسية مثل القتل والذبح. فالإسلام يأمر بالإحسان حتى مع الحيوان عند ذبحه',
    'reference': 'رواه مسلم'
  },
  {
    'number': 18,
    'text': 'اتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن',
    'explanation': 'هذا الحديث يجمع ثلاث وصايا: التقوى في كل مكان، ومقابلة السيئة بالحسنة، وحسن الخلق مع الناس. فالتقوى هي خشية الله في السر والعلن، ومقابلة السيئة بالحسنة تمحو أثرها، وحسن الخلق يجلب محبة الناس',
    'reference': 'رواه الترمذي'
  },
  {
    'number': 19,
    'text': 'احفظ الله يحفظك، احفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله، واعلم أن الأمة لو اجتمعت على أن ينفعوك بشيء لم ينفعوك إلا بشيء قد كتبه الله لك، وإن اجتمعوا على أن يضروك بشيء لم يضروك إلا بشيء قد كتبه الله عليك؛ رفعت الأقلام، وجفت الصحف',
    'explanation': 'هذا الحديث يبين أن من يحفظ الله بطاعته يحفظه الله في دينه ودنياه. ويأمر بالتوكل على الله في السؤال والاستعانة، ويؤكد أن الأقدار لا تتغير، فما كتب للعبد من نفع أو ضر لا بد أن يصيبه',
    'reference': 'رواه الترمذي'
  },
  {
    'number': 20,
    'text': 'إن مما أدرك الناس من كلام النبوة الأولى: إذا لم تستح فاصنع ما شئت',
    'explanation': 'هذا الحديث يبين أن الحياء من الإيمان، وهو مانع من المعاصي. فمن فقد الحياء فقد فعل ما شاء من القبائح، والحياء خلق كريم يمنع صاحبه من ارتكاب المحرمات',
    'reference': 'رواه البخاري'
  },
  {
    'number': 21,
    'text': 'قل آمنت بالله ثم استقم',
    'explanation': 'هذا الحديث يوجز طريق السعادة في كلمتين: الإيمان ثم الاستقامة. فالإيمان هو الأساس، والاستقامة هي الثبات على طاعة الله واجتناب معصيته',
    'reference': 'رواه مسلم'
  },
  {
    'number': 22,
    'text': 'أرأيت إذا صليت المكتوبات، وصمت رمضان، وأحللت الحلال، وحرمت الحرام، ولم أزد على ذلك شيئا؛ أأدخل الجنة؟ قال: نعم',
    'explanation': 'هذا الحديث يبين أن من أدى الفرائض واجتنب المحرمات دخل الجنة. فهو يبشر بأن الجنة لمن التزم بأركان الإسلام وابتعد عن المحرمات',
    'reference': 'رواه مسلم'
  },
  {
    'number': 23,
    'text': 'الطهور شطر الإيمان، والحمد لله تملأ الميزان، وسبحان الله والحمد لله تملآن -أو: تملأ- ما بين السماء والأرض، والصلاة نور، والصدقة برهان، والصبر ضياء، والقرآن حجة لك أو عليك، كل الناس يغدو، فبائع نفسه فمعتقها أو موبقها',
    'explanation': 'هذا الحديث يبين فضائل عدة من أعمال البر: الطهارة، والتسبيح، والتحميد، والصلاة، والصدقة، والصبر، وتلاوة القرآن. ويختم بأن الإنسان إما أن يعتق نفسه بطاعة الله أو يوبقها بمعصيته',
    'reference': 'رواه مسلم'
  },
  {
    'number': 24,
    'text': 'يا عبادي: إني حرمت الظلم على نفسي، وجعلته بينكم محرما؛ فلا تظالموا. يا عبادي! كلكم ضال إلا من هديته، فاستهدوني أهدكم. يا عبادي! كلكم جائع إلا من أطعمته، فاستطعموني أطعمكم. يا عبادي! كلكم عار إلا من كسوته، فاستكسوني أكسكم. يا عبادي! إنكم تخطئون بالليل والنهار، وأنا أغفر الذنوب جميعا؛ فاستغفروني أغفر لكم. يا عبادي! إنكم لن تبلغوا ضري فتضروني، ولن تبلغوا نفعي فتنفعوني. يا عبادي! لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أتقى قلب رجل واحد منكم، ما زاد ذلك في ملكي شيئا. يا عبادي! لو أن أولكم وآخركم وإنسكم وجنكم كانوا على أفجر قلب رجل واحد منكم، ما نقص ذلك من ملكي شيئا. يا عبادي! لو أن أولكم وآخركم وإنسكم وجنكم قاموا في صعيد واحد، فسألوني، فأعطيت كل واحد مسألته، ما نقص ذلك مما عندي إلا كما ينقص المخيط إذا أدخل البحر. يا عبادي! إنما هي أعمالكم أحصيها لكم، ثم أوفيكم إياها؛ فمن وجد خيرا فليحمد الله، ومن وجد غير ذلك فلا يلومن إلا نفسه',
    'explanation': 'هذا الحديث القدسي يبين عدل الله ورحمته وغناه عن خلقه. فيه تحريم الظلم، وبيان أن الهداية والرزق والكسوة من الله، وسعة مغفرته، وأنه الغني عن العالمين، وأن الجزاء على الأعمال',
    'reference': 'رواه مسلم'
  },
  {
    'number': 25,
    'text': 'ذهب أهل الدثور بالأجور؛ يصلون كما نصلي، ويصومون كما نصوم، ويتصدقون بفضول أموالهم. قال: أوليس قد جعل الله لكم ما تصدقون؟ إن بكل تسبيحة صدقة، وكل تكبيرة صدقة، وكل تحميدة صدقة، وكل تهليلة صدقة، وأمر بمعروف صدقة، ونهي عن منكر صدقة، وفي بضع أحدكم صدقة. قالوا: يا رسول الله أيأتي أحدنا شهوته ويكون له فيها أجر؟ قال: أرأيتم لو وضعها في حرام أكان عليه وزر؟ فكذلك إذا وضعها في الحلال، كان له أجر',
    'explanation': 'هذا الحديث يبين أن أبواب الخير كثيرة وليست مقصورة على الأموال فقط. فكل تسبيحة وتكبيرة وتحمدية وتهليلة صدقة، والأمر بالمعروف والنهي عن المنكر صدقة، حتى الجماع الحلال يكون فيه أجر',
    'reference': 'رواه مسلم'
  },
  {
    'number': 26,
    'text': 'كل سلامى من الناس عليه صدقة، كل يوم تطلع فيه الشمس تعدل بين اثنين صدقة، وتعين الرجل في دابته فتحمله عليها أو ترفع له عليها متاعه صدقة، والكلمة الطيبة صدقة، وبكل خطوة تمشيها إلى الصلاة صدقة، وتميط الأذى عن الطريق صدقة',
    'explanation': 'هذا الحديث يبين أنواع الصدقات المتعددة التي يمكن للمسلم أن يؤديها، فليس الصدقة مقصورة على المال فقط، بل كل معروف صدقة، والإصلاح بين الناس صدقة، والكلمة الطيبة صدقة، وإماطة الأذى صدقة',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 27,
    'text': 'البر حسن الخلق، والإثم ما حاك في صدرك، وكرهت أن يطلع عليه الناس',
    'explanation': 'هذا الحديث يبين أن البر هو حسن الخلق، والإثم ما حاك في النفس وكره الإنسان أن يطلع عليه الناس. فالفطرة السليمة تميز بين الخير والشر، والقلب يأنس للبر وينكر الإثم',
    'reference': 'رواه مسلم'
  },
  {
    'number': 28,
    'text': 'أوصيكم بتقوى الله، والسمع والطاعة وإن تأمر عليكم عبد، فإنه من يعش منكم فسيرى اختلافا كثيرا، فعليكم بسنتي وسنة الخلفاء الراشدين المهديين، عضوا عليها بالنواجذ، وإياكم ومحدثات الأمور؛ فإن كل بدعة ضلالة',
    'explanation': 'هذا الحديث وصية بالتمسك بتقوى الله وطاعة ولي الأمر، والتمسك بالسنة النبوية وسنة الخلفاء الراشدين، والتحذير من البدع والمحدثات في الدين، فإن كل بدعة ضلالة',
    'reference': 'رواه أبو داود والترمذي'
  },
  {
    'number': 29,
    'text': 'تعبد الله لا تشرك به شيئا، وتقيم الصلاة، وتؤتي الزكاة، وتصوم رمضان، وتحج البيت، ثم قال: ألا أدلك على أبواب الخير؟ الصوم جنة، والصدقة تطفئ الخطيئة كما يطفئ الماء النار، وصلاة الرجل في جوف الليل، ثم تلا: "تتجافى جنوبهم عن المضاجع" حتى بلغ "يعملون"، ثم قال: ألا أخبرك برأس الأمر وعموده وذروة سنامه؟ قلت: بلى يا رسول الله. قال: رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد، ثم قال: ألا أخبرك بمالك ذلك كله؟ فقلت: بلى يا رسول الله! فأخذ بلسانه وقال: كف عليك هذا. قلت: يا نبي الله وإنا لمؤاخذون بما نتكلم به؟ فقال: ثكلتك أمك وهل يكب الناس على وجوههم -أو قال على مناخرهم- إلا حصائد ألسنتهم؟!',
    'explanation': 'هذا الحديث يبين أركان الإسلام وفضائل الصوم والصدقة والصلاة، ثم يبين أن رأس الأمر الإسلام، وعموده الصلاة، وذروة سنامه الجهاد. ثم يحذر من خطر اللسان، فإن كثيرا من الناس يهلكون بسبب أقوالهم',
    'reference': 'رواه الترمذي'
  },
  {
    'number': 30,
    'text': 'إن الله تعالى فرض فرائض فلا تضيعوها، وحد حدودا فلا تعتدوها، وحرم أشياء فلا تنتهكوها، وسكت عن أشياء رحمة لكم غير نسيان فلا تبحثوا عنها',
    'explanation': 'هذا الحديث يبين أصول التعامل مع الشرع: المحافظة على الفرائض، وعدم تجاوز الحدود، واجتناب المحرمات، وترك البحث عما سكت عنه الشرع رحمة بالأمة',
    'reference': 'رواه الدارقطني'
  },
  {
    'number': 31,
    'text': 'ازهد في الدنيا يحبك الله، وازهد فيما عند الناس يحبك الناس',
    'explanation': 'هذا الحديث يبين أن الزهد في الدنيا وفيما عند الناس طريق إلى محبة الله ومحبة الناس. فمن لم يهتم بالدنيا ولم يحسد الناس على ما عندهم أحبه الله وأحبه الناس',
    'reference': 'رواه ابن ماجة'
  },
  {
    'number': 32,
    'text': 'لا ضرر ولا ضرار',
    'explanation': 'هذا الحديث قاعدة عظيمة من قواعد الإسلام، تحرم الضرر والضرار. فليس للإنسان أن يضر نفسه ولا أن يضر غيره، وهذا من كمال العدل في الإسلام',
    'reference': 'رواه ابن ماجة والدارقطني'
  },
  {
    'number': 33,
    'text': 'لو يعطى الناس بدعواهم لادعى رجال أموال قوم ودماءهم، ولكن البينة على المدعي، واليمين على من أنكر',
    'explanation': 'هذا الحديث يبين أصول الإثبات في القضاء، فليس مجرد الدعوى كافيا، بل لا بد من البينة (الشهود أو الإقرار). فالبينة على المدعي، وإذا أنكر المدعى عليه يحلف',
    'reference': 'رواه البيهقي'
  },
  {
    'number': 34,
    'text': 'من رأى منكم منكرا فليغيره بيده، فإن لم يستطع فبلسانه، فإن لم يستطع فبقلبه، وذلك أضعف الإيمان',
    'explanation': 'هذا الحديث يبين مراتب تغيير المنكر حسب الاستطاعة: التغيير باليد لمن له سلطة، ثم باللسان بالنصيحة، ثم بالقلب (بكراهية المنكر). والتغيير بالقلب هو أضعف الإيمان',
    'reference': 'رواه مسلم'
  },
  {
    'number': 35,
    'text': 'لا تحاسدوا، ولا تناجشوا، ولا تباغضوا، ولا تدابروا، ولا يبع بعضكم على بيع بعض، وكونوا عباد الله إخوانا، المسلم أخو المسلم، لا يظلمه، ولا يخذله، ولا يكذبه، ولا يحقره، التقوى هاهنا، ويشير إلى صدره ثلاث مرات، بحسب امرئ من الشر أن يحقر أخاه المسلم، كل المسلم على المسلم حرام: دمه وماله وعرضه',
    'explanation': 'هذا الحديث يجمع آداب التعامل بين المسلمين، فينهى عن الحسد والنجش (الغش في البيع) والبغضاء والهجران، ويأمر بالإخاء الإسلامي. ويبين حرمة دم المسلم وماله وعرضه',
    'reference': 'رواه مسلم'
  },
  {
    'number': 36,
    'text': 'من نفس عن مؤمن كربة من كرب الدنيا نفس الله عنه كربة من كرب يوم القيامة، ومن يسر على معسر، يسر الله عليه في الدنيا والآخرة، ومن ستر مسلما ستره الله في الدنيا والآخرة، والله في عون العبد ما كان العبد في عون أخيه، ومن سلك طريقا يلتمس فيه علما سهل الله له به طريقا إلى الجنة، وما اجتمع قوم في بيت من بيوت الله يتلون كتاب الله، ويدرسونه فيما بينهم؛ إلا نزلت عليهم السكينة، وغشيتهم الرحمة، وذكرهم الله فيمن عنده، ومن أبطأ به عمله لم يسرع به نسبه',
    'explanation': 'هذا الحديث يبين فضائل إزالة الكرب والتيسير على المعسرين والستر وطلب العلم. فمن helped أخاه helpedه الله، ومن ستر مسلما ستره الله، ومن طلب العلم سهل الله له طريق الجنة',
    'reference': 'رواه مسلم'
  },
  {
    'number': 37,
    'text': 'إن الله كتب الحسنات والسيئات، ثم بين ذلك، فمن هم بحسنة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله عنده عشر حسنات إلى سبعمائة ضعف إلى أضعاف كثيرة، وإن هم بسيئة فلم يعملها كتبها الله عنده حسنة كاملة، وإن هم بها فعملها كتبها الله سيئة واحدة',
    'explanation': 'هذا الحديث يبين كرم الله تعالى في كتابة الحسنات والسيئات. فمن هم بحسنة كتبت له حسنة كاملة وإن لم يعملها، وإذا عملها كتبت له عشر حسنات إلى سبعمائة ضعف. ومن هم بسيئة لم تكتب عليه إذا تركها، بل تكتب له حسنة، وإذا عملها تكتب سيئة واحدة',
    'reference': 'رواه البخاري ومسلم'
  },
  {
    'number': 38,
    'text': 'من عادى لي وليا فقد آذنته بالحرب، وما تقرب إلي عبدي بشيء أحب إلي مما افترضته عليه، ولا يزال عبدي يتقرب إلي بالنوافل حتى أحبه، فإذا أحببته كنت سمعه الذي يسمع به، وبصره الذي يبصر به، ويده التي يبطش بها، ورجله التي يمشي بها، ولئن سألني لأعطينه، ولئن استعاذني لأعيذنه',
    'explanation': 'هذا الحديث يبين مكانة أولياء الله وثمرات التقرب إليه بالفرائض والنوافل. فمن عادى وليا لله فقد declared الحرب على الله. ومن تقرب إلى الله بالفرائض ثم النوافل أحبه الله وكان معه في جميع أحواله',
    'reference': 'رواه البخاري'
  },
  {
    'number': 39,
    'text': 'إن الله تجاوز لي عن أمتي الخطأ والنسيان وما استكرهوا عليه',
    'explanation': 'هذا الحديث يبين رحمة الله تعالى بأمته، حيث رفع المؤاخذة عن الخطأ والنسيان والإكراه. فليس على الإنسان إثم في ما أخطأ أو نسي أو أكره عليه',
    'reference': 'رواه ابن ماجة والبيهقي'
  },
  {
    'number': 40,
    'text': 'كن في الدنيا كأنك غريب أو عابر سبيل. وكان ابن عمر يقول: إذا أمسيت فلا تنتظر الصباح، وإذا أصبحت فلا تنتظر المساء، وخذ من صحتك لمرضك، ومن حياتك لموتك',
    'explanation': 'هذا الحديث يأمر بالزهد في الدنيا وعدم التعلق بها، وأن يعامل الإنسان الدنيا معاملة الغريب أو المسافر. ويوصي بالاستعداد للآخرة بالأعمال الصالحة',
    'reference': 'رواه البخاري'
  },
  {
    'number': 41,
    'text': 'لا يؤمن أحدكم حتى يكون هواه تبعا لما جئت به',
    'explanation': 'هذا الحديث يبين أن الإيمان الكامل يتطلب انقياد الهوى لشرع الله. فالمؤمن الحقيقي هو الذي يخضع هواه لما جاء به النبي صلى الله عليه وسلم',
    'reference': 'حديث حسن صحيح'
  },
  {
    'number': 42,
    'text': 'يا ابن آدم! إنك ما دعوتني ورجوتني غفرت لك على ما كان منك ولا أبالي، يا ابن آدم! لو بلغت ذنوبك عنان السماء ثم استغفرتني غفرت لك، يا ابن آدم! إنك لو أتيتني بقُراب الأرض خطايا ثم لقيتني لا تشرك بي شيئا لأتيتك بقُرابها مغفرة',
    'explanation': 'هذا الحديث يبين سعة مغفرة الله تعالى لمن دعاه ورجاه ولم يشرك به. فمهما عظمت ذنوب العبد فإن مغفرة الله أعظم، إذا تاب وأناب ولم يشرك بالله',
    'reference': 'رواه الترمذي'
  }

  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.all(20),
      itemCount: hadithData.length,
      itemBuilder: (context, index) {
        final hadith = hadithData[index];
        return _buildHadithCard(hadith, context);
      },
    );
  }

  Widget _buildHadithCard(Map<String, dynamic> hadith, BuildContext context) {
    return Card(
      margin: EdgeInsets.only(bottom: 15),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        leading: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Color(0xFF1E8449),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              '${hadith['number']}',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        title: Text(
          hadith['text'].length > 100
              ? '${hadith['text'].substring(0, 100)}...'
              : hadith['text'],
          style: TextStyle(
            fontSize: 16,
            fontFamily: 'Amiri',
            color: Color(0xFF2c3e50),
          ),
        ),
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hadith['text'],
                  style: TextStyle(
                    fontSize: 18,
                    fontFamily: 'Amiri',
                    color: Color(0xFF2c3e50),
                    height: 1.8,
                  ),
                ),
                SizedBox(height: 15),
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    hadith['explanation'],
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFF6c757d),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  hadith['reference'],
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF95a5a6),
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Duas Section
class DuasSection extends StatelessWidget {
  final List<Map<String, dynamic>> duasData = [
    {
    'title': 'دعاء الكرب والهم',
    'arabic': 'لا إِلَهَ إِلا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
    'translation': 'لا إله إلا أنت سبحانك إني كنت من الظالمين',
    'occasion': 'يقال عند الكرب والهم والضيق'
  },
  {
    'title': 'دعاء دخول المسجد',
    'arabic': 'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ',
    'translation': 'اللهم افتح لي أبواب رحمتك',
    'occasion': 'عند دخول المسجد'
  },
  {
    'title': 'دعاء الخروج من المسجد',
    'arabic': 'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ وَرَحْمَتِكَ',
    'translation': 'اللهم إني أسألك من فضلك ورحمتك',
    'occasion': 'عند الخروج من المسجد'
  },
  {
    'title': 'دعاء الرزق',
    'arabic': 'اللَّهُمَّ اكْفِنِي بِحَلالِكَ عَنْ حَرَامِكَ، وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ',
    'translation': 'اللهم اكفني بحلالك عن حرامك، وأغنني بفضلك عمن سواك',
    'occasion': 'لطلب الرزق الحلال والغنى عن الناس'
  },
  {
    'title': 'دعاء الهم والحزن',
    'arabic': 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْجُبْنِ وَالْبُخْلِ، وَضَلَعِ الدَّيْنِ، وَقهر الرِّجَالِ',
    'translation': 'اللهم إني أعوذ بك من الهم والحزن، والعجز والكسل، والجبن والبخل، وضلع الدين، وقهر الرجال',
    'occasion': 'عند الشعور بالهم والحزن والضيق'
  },
  {
    'title': 'دعاء الاستعاذة من النار',
    'arabic': 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ عَذَابِ جَهَنَّمَ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، وَأَعُوذُ بِكَ مِنْ فِتْنَةِ الْمَسِيحِ الدَّجَّالِ، وَأَعُوذُ بِكَ مِنْ فِتْنَةِ الْمَحْيَا وَالْمَمَاتِ',
    'translation': 'اللهم إني أعوذ بك من عذاب جهنم، وأعوذ بك من عذاب القبر، وأعوذ بك من فتنة المسيح الدجال، وأعوذ بك من فتنة المحيا والممات',
    'occasion': 'للتحصين من عذاب النار وفتن الدنيا ويقال بعد التشهد وقبل التسليم'
  },
  {
    'title': 'دعاء لقضاء الدين',
    'arabic': 'اللَّهُمَّ اكْفِنِي بِحَلالِكَ عَنْ حَرَامِكَ، وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ',
    'translation': 'اللهم اكفني بحلالك عن حرامك، وأغنني بفضلك عمن سواك',
    'occasion': 'لقضاء الدين والغنى عن سؤال الناس'
  },
  {
    'title': 'دعاء السفر',
    'arabic': 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ، وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ، اللَّهُمَّ إِنَّا نَسْأَلُكَ فِي سَفَرِنَا هَذَا الْبِرَّ وَالتَّقْوَى، وَمِنَ الْعَمَلِ mَا تَرْضَى، اللَّهُمَّ هَوِّنْ عَلَيْنَا سَفَرَنَا هَذَا، وَاطْوِ عَنَّا بُعْدَهُ، اللَّهُمَّ أَنْتَ الصَّاحِبُ فِي السَّفَرِ، وَالْخَلِيفَةُ فِي الأَهْلِ، اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ وَعْثَاءِ السَّفَرِ، وَكَآبَةِ الْمَنْظَرِ، وَسُوءِ الْمُنْقَلَبِ فِي الْمَالِ وَالأَهْلِ',
    'translation': 'سبحان الذي سخر لنا هذا وما كنا له مقرنين، وإنا إلى ربنا لمنقلبون، اللهم إنا نسألك في سفرنا هذا البر والتقوى، ومن العمل ما ترضى، اللهم هون علينا سفرنا هذا، واطو عنا بعده، اللهم أنت الصاحب في السفر، والخليفة في الأهل، اللهم إني أعوذ بك من وعثاء السفر، وكآبة المنظر، وسوء المنقلب في المال والأهل',
    'occasion': 'عند البدء في السفر'
  },
  {
    'title': 'دعاء دخول المنزل',
    'arabic': 'اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلِجِ وَخَيْرَ الْمَخْرَجِ، بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا',
    'translation': 'اللهم إني أسألك خير المولج وخير المخرج، بسم الله ولجنا، وبسم الله خرجنا، وعلى الله ربنا توكلنا',
    'occasion': 'عند دخول المنزل'
  },
  {
    'title': 'دعاء الخروج من المنزل',
    'arabic': 'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    'translation': 'بسم الله، توكلت على الله، ولا حول ولا قوة إلا بالله',
    'occasion': 'عند الخروج من المنزل'
  },
  {
    'title': 'دعاء لبس الثوب الجديد',
    'arabic': 'اللَّهُمَّ لَكَ الْحَمْدُ أَنْتَ كَسَوْتَنِيهِ، أَسْأَلُكَ خَيْرَهُ وَخَيْرَ مَا صُنِعَ لَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّهِ وَشَرِّ مَا صُنِعَ لَهُ',
    'translation': 'اللهم لك الحمد أنت كسوتنيه، أسألك خيره وخير ما صنع له، وأعوذ بك من شره وشر ما صنع له',
    'occasion': 'عند لبس الثوب الجديد'
  },
  {
    'title': 'دعاء النظر في المرآة',
    'arabic': 'اللَّهُمَّ كَمَا حَسَّنْتَ خَلْقِي فَحَسِّنْ خُلُقِي',
    'translation': 'اللهم كما حسنت خلقي فحسن خلقي',
    'occasion': 'عند النظر في المرآة'
  },
  {
    'title': 'دعاء الريح',
    'arabic': 'اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَهَا، وَخَيْرَ مَا فِيهَا، وَخَيْرَ mَا أُرْسِلَتْ بِهِ، وَأَعُوذُ بِكَ مِنْ شَرِّهَا، وَشَرِّ mَا فِيهَا، وَشَرِّ mَا أُرْسِلَتْ بِهِ',
    'translation': 'اللهم إني أسألك خيرها، وخير ما فيها، وخير ما أرسلت به، وأعوذ بك من شرها، وشر ما فيها، وشر ما أرسلت به',
    'occasion': 'عند هبوب الريح'
  },
  {
    'title': 'دعاء المطر',
    'arabic': 'اللَّهُمَّ صَيِّباً نَافِعاً',
    'translation': 'اللهم صيباً نافعاً',
    'occasion': 'عند نزول المطر'
  },
  {
    'title': 'دعاء بعد الانتهاء من المطر',
    'arabic': 'مُطِرْنَا بِفَضْلِ اللَّهِ وَرَحْمَتِهِ',
    'translation': 'مطرنا بفضل الله ورحمته',
    'occasion': 'بعد انتهاء المطر'
  },
  {
    'title': 'دعاء رؤية الهلال',
    'arabic': 'اللَّهُمَّ أَهِلَّهُ عَلَيْنَا بِالْيُمْنِ وَالإِيمَانِ، وَالسَّلامَةِ وَالإِسْلامِ، رَبِّي وَرَبُّكَ اللَّهُ',
    'translation': 'اللهم أهله علينا باليمن والإيمان، والسلامة والإسلام، ربي وربك الله',
    'occasion': 'عند رؤية هلال الشهر الجديد'
  },
  {
    'title': 'دعاء عيادة المريض',
    'arabic': 'لا بَأْسَ طَهُورٌ إِنْ شَاءَ اللَّهُ',
    'translation': 'لا بأس طهور إن شاء الله',
    'occasion': 'عند زيارة المريض'
  },
  {
    'title': 'دعاء لبس الثوب',
    'arabic': 'الْحَمْدُ لِلَّهِ الَّذِي كَسَانِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلا قُوَّةٍ',
    'translation': 'الحمد لله الذي كساني هذا ورزقنيه من غير حول مني ولا قوة',
    'occasion': 'عند لبس الثوب الجديد'
  }
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(20),
          child: Text(
            'الأدعية المأثورة',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1E8449),
              fontFamily: 'Amiri',
            ),
            textAlign: TextAlign.center,
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 20),
            itemCount: duasData.length,
            itemBuilder: (context, index) {
              final dua = duasData[index];
              return _buildDuaCard(dua, index, context);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDuaCard(Map<String, dynamic> dua, int index, BuildContext context) {
    return Card(
      margin: EdgeInsets.only(bottom: 15),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        leading: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            color: Color(0xFF1E8449),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              '${index + 1}',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ),
        title: Text(
          dua['title'],
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFF1E8449),
            fontFamily: 'Amiri',
          ),
        ),
        children: [
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Color(0xFFf0f8f0),
                    borderRadius: BorderRadius.circular(8),
                    border: Border(
                      right: BorderSide(color: Color(0xFF1E8449), width: 4),
                    ),
                  ),
                  child: Text(
                    dua['arabic'],
                    style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Amiri',
                      color: Color(0xFF2c3e50),
                      height: 1.8,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 15),
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border(
                      right: BorderSide(color: Color(0xFF27AE60), width: 3),
                    ),
                  ),
                  child: Text(
                    dua['translation'],
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFF6c757d),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  dua['occasion'],
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF95a5a6),
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Supplications Section
class SupplicationsSection extends StatefulWidget {
  @override
  _SupplicationsSectionState createState() => _SupplicationsSectionState();
}

class _SupplicationsSectionState extends State<SupplicationsSection> {
  String currentCategory = 'morning';

  final Map<String, List<Map<String, dynamic>>> supplicationsData = {
    'morning': [
      {
        'title': 'آية الكرسي',
    'arabic': 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحْيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضِ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
    'translation': 'الله لا إله إلا هو الحي القيوم، لا تأخذه سنة ولا نوم، له ما في السماوات وما في الأرض...',
    'time': 'من قالها حين يصبح أجير من الجن حتى يمسي'
  },
  {
    'title': 'الشهادة',
    'arabic': 'اللهم إني أصبحتُ أُشهدكَ وأُشهدُ حملةَ عرشك وملائكتكَ وجميع خلقك أنك أنت الله لا إله إلا أنت وحدك لا شريك لك وأن محمدًا عَبدُكَ ورسولك.',
    'translation': 'اللهم إني أصبحتُ أُشهدكَ وأُشهدُ حملةَ عرشك وملائكتكَ وجميع خلقك أنك أنت الله لا إله إلا أنت وحدك لا شريك لك وأن محمدًا عَبدُكَ ورسولك...',
    'time': 'مرة واحدة. من قالها حين يصبح أو يمسي أربع مرات أعتقه الله من النار. (رواه أبو داود)'
  },
  {
    'title': 'الدعاء بالعفو والعافية',
    'arabic': 'اللهم إني أسألك العفو والعافية في الدنيا والآخرة، اللهم إني أسألك العفو والعافية في ديني ودنياي وأهلي ومالي، اللهم استر عوراتي، وآمن روعاتي، اللهم احفظني من بين يدي ومن خلفي، وعن يميني وعن شمالي، ومن فوقي وأعوذ بعظمتك أن أُغتالَ من تحتي',
    'translation': 'اللهم إني أسألك العفو والعافية في الدنيا والآخرة، اللهم إني أسألك العفو والعافية في ديني ودنياي وأهلي ومالي، اللهم استر عوراتي، وآمن روعاتي، اللهم احفظني من بين يدي ومن خلفي، وعن يميني وعن شمالي، ومن فوقي وأعوذ بعظمتك أن أُغتالَ من تحتي....',
    'time': '(رواه أبو داود)'
  },
  {
    'title': 'سيد الاستغفار',
    'arabic': 'اللهم انت ربي خلقتني وانا عبدك وانا علي عهدك ووعدك ما استطعت. أعوذ بك من شر ما صنعت وأبوء بذنبي فاغفر لي. فإنه لا يغفر الذنوب إلا أنت',
    'translation': 'اللهم انت ربي خلقتني وانا عبدك وانا علي عهدك ووعدك ما استطعت. أعوذ بك من شر ما صنعت وأبوء بذنبي فاغفر لي. فإنه لا يغفر الذنوب إلا أنت',
    'time': 'من قالها موقن بها حين يصبح فمات من يومه داخل الجنة'
  },
  {
    'title': 'الرضا بالله رباً',
    'arabic': 'رضيت بالله ربا وبالإسلام ديناً وبمحمد صلى الله عليه وسلم نبياً ورسولاً',
    'translation': 'رضيت بالله ربا وبالإسلام ديناً وبمحمد صلى الله عليه وسلم نبياً ورسولاً',
    'time': 'صلي على النبي'
  },
  {
    'title': 'الدعاء بالحياة والموت',
    'arabic': 'اللهم بك أصبحنا، وبك أمسينا، وبك نحيا، وبك نموت، وإليك النشور.',
    'translation': 'اللهم بك أصبحنا، وبك أمسينا، وبك نحيا، وبك نموت، وإليك النشور ...',
    'time': '(رواه الترمذي)'
  },
  {
    'title': 'الفطرة',
    'arabic': 'أصبحنا على فطرةِ الإسلام، وعلى كلمةِ الإخلاص، وعلى دين نبينا محمدٍ صلى الله عليه وسلم، وعلى ملةِ أبينا إبراهيم حنيفًا مسلمًا وما كان من المشركين',
    'translation': 'أصبحنا على فطرةِ الإسلام، وعلى كلمةِ الإخلاص، وعلى دين نبينا محمدٍ صلى الله عليه وسلم، وعلى ملةِ أبينا إبراهيم حنيفًا مسلمًا وما كان من المشركين',
    'time': 'رواه أحمد'
  },
  {
    'title': 'الثناء على الله',
    'arabic': 'يا رَبِّ لك الحمدُ كما يَنْبَغِي لجلالِ وجهِك ولِعَظِيمِ سُلْطَانِكَ.',
    'translation': 'يا رَبِّ لك الحمدُ كما يَنْبَغِي لجلالِ وجهِك ولِعَظِيمِ سُلْطَانِكَ....',
    'time': 'الملكين يقولان: يا الله إن عبدك قال مقالة لا ندري كيف نكتبها. قال الله عز وجل وهو أعلم بما قال عبده: ماذا قال عبدي؟ قالا: يارب إنه قال (يارب لك الحمد كما ينبغي لجلال وجهك ولعظيم سلطانك). فقال الله عز وجل لهما: اكتباها كما قال عبدي حتى يلقاني فأجزيه بها.'
  },
  {
    'title': 'الدعاء بالعافية',
    'arabic': 'اللهمَّ عافني في بدني، اللهم عافني في سمعي، اللهم عافني في بصري، لا إله إلا أنت. اللهم إني أعوذ بك من الكُـفرِ والفقر، وأعوذ بك من عذابِ القبر، لا إله إلا أنت',
    'translation': 'اللهمَّ عافني في بدني، اللهم عافني في سمعي، اللهم عافني في بصري، لا إله إلا أنت. اللهم إني أعوذ بك من الكُـفرِ والفقر، وأعوذ بك من عذابِ القبر، لا إله إلا أنت',
    'time': '(رواه أحمد)'
  },
  {
    'title': 'حفظ الله لك',
    'arabic': 'بسمِ اللهِ الذي لا يضرُّ مع اسمِه شيءٌ في الأرضِ ولا في السماءِ وهو السميعُ العليمُ.',
    'translation': 'بسمِ اللهِ الذي لا يضرُّ مع اسمِه شيءٌ في الأرضِ ولا في السماءِ وهو السميعُ العليمُ....',
    'time': 'من قالها ثلاثًا إذا أصبح وثلاثًا إذا أمسى لم يضره شيء. (رواه ابن ماجة)'
  },
  {
    'title': 'التوكل على الله',
    'arabic': 'حسبي الله لا إله إلا هو عليه توكلتُ وهو ربُّ العرش العظيم.',
    'translation': 'حسبي الله لا إله إلا هو عليه توكلتُ وهو ربُّ العرش العظيم....',
    'time': 'من قالها حين يصبح وحين يمسي سبع مرات كفاه الله ما أهمه من أمر الدنيا والآخرة. (رواه ابن السني)'
  },
  {
    'title': 'دعاء الصباح',
    'arabic': 'أصبحنا وأصبح المُلك لله ربِّ العالمين، اللهم إني أسألك خير هذا اليوم، فتحه ونصره ونوره وبركته وهُداه، وأعوذ بك من شرِّ ما فيه وشرِّ ما بعده',
    'translation': 'أصبحنا وأصبح المُلك لله ربِّ العالمين، اللهم إني أسألك خier هذا اليوم، فتحه ونصره ونوره وبركته وهُداه، وأعوذ بك من شرِّ ما فيه وشرِّ ما بعده...',
    'time': '(رواه أبو داود)'
  },
  {
    'title': 'الدعاء من شر النفس والشيطان',
    'arabic': 'اللهم عالمَ الغيبِ والشهادة فاطرَ السمواتِ والأرض، ربَّ كل شيء ٍ ومليكه أشهدُ أن لا إله إلا أنت، أعوذ بك من شرِّ نفسي، ومن شرِّ الشيطانِ وشَركِه، وأن أقترفَ على نفسي سوءًا، أو أجُـرَّهُ إلى مسلم',
    'translation': 'اللهم عالمَ الغيبِ والشهادة فاطرَ السمواتِ والأرض، ربَّ كل شيء ٍ ومليكه أشهدُ أن لا إله إلا أنت، أعوذ بك من شرِّ نفسي، ومن شرِّ الشيطانِ وشَركِه، وأن أقترفَ على نفسي سوءًا، أو أجُـرَّهُ إلى مسلم',
    'time': '(رواه الترمذي)'
  },
  {
    'title': 'شكر النعم',
    'arabic': 'اللهم ما أصبح بي من نعمة أو بأحدٍ من خلقك فـَمِنكَ وحدك لا شريك لك فلك الحمدُ ولك الشكر.',
    'translation': 'اللهم ما أصبح بي من نعمة أو بأحدٍ من خلقك فـَمِنكَ وحدك لا شريك لك فلك الحمدُ ولك الشكر....',
    'time': 'من قالها حين يصبح فقد أدى شكر يومه'
  },
  {
    'title': 'الاستعاذة',
    'arabic': 'أعوذ بكلمات الله التامات من شر ما خلق',
    'translation': 'أعوذ بكلمات الله التامات من شر ما خلق...',
    'time': 'ثلاث مرات'
  },
  {
    'title': 'الاستغفار',
    'arabic': 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه.',
    'translation': 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه....',
    'time': 'مرة واحدة'
  },
  {
    'title': 'الصلاة على النبي',
    'arabic': 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ على نَبِيِّنَا مُحمَّد',
    'translation': 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ على نَبِيِّنَا مُحمَّد...',
    'time': 'في الحديث الصحيح: من صلى علي صلاة واحدة صلى الله عليه بها عشراً'
  },
  {
    'title': 'سورة الإخلاص',
    'arabic': 'قل هو الله أحد (1) الله الصمد (2) لم يلد ولم يولد (3) ولم يكن له كفواً أحد (4)',
    'translation': 'قل هو الله أحد (1) الله الصمد (2) لم يلد ولم يولد (3) ولم يكن له كفواً أحد (4)',
    'time': 'من قالها حين يصبح وحين يمسي كفته من كل شيء (الإخلاص والمعوذتين). (رواه أبو داود والترمذي)'
  },
  {
    'title': 'سورة الفلق',
    'arabic': 'قل أعوذ برب الفلق (1) من شر ما خلق (2) ومن شر غاسق إذا وقب (3) ومن شر النفاثات في العقد (4) ومن شر حاسد إذا حسد (5)',
    'translation': 'قل أعوذ برب الفلق (1) من شر ما خلق (2) ومن شر غاسق إذا وقب (3) ومن شر النفاثات في العقد (4) ومن شر حاسد إذا حسد (5)',
    'time': '(صدق الله العظيم)'
  },
  {
    'title': 'سورة الناس',
    'arabic': 'قل أعوذ برب الناس (1) ملك الناس (2) إله الناس (3) من شر الوسواس الخناس (4) الذي يوسوس في صدور الناس (5) من الجنة والناس (6)',
    'translation': 'قل أعوذ برب الناس (1) ملك الناس (2) إله الناس (3) من شر الوسواس الخناس (4) الذي يوسوس في صدور الناس (5) من الجنة والناس (6)',
    'time': 'ثلاث مرات هي والفلق والإخلاص'
  },
  {
    'title': 'التسبيح',
    'arabic': 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ عَدَدَ خَلْقِهِ وَرِضَا نَفْسِهِ وَزِنَةَ عَرْشِهِ وَمِدَادَ كَلِمَاتِهِ',
    'translation': 'سبحان الله وبحمده عدد خلقه ورضا نفسه وزنة عرشه ومداد كلماته',
    'time': 'يُقال في الصباح ثلاث مرات'
  },
  {
    'title': 'دعاء الصباح الكامل',
    'arabic': 'أصبحنا وصبح الملك لله والحمد لله. لا إله إلا الله وحده لا شريك له. له الملك وله الحمد وهو على كل شيء قدير. رب أسألك خير ما في هذا اليوم وخير ما بعده. وأعوذ بك من شر ما في اليوم وشر ما بعده. رب أعوذ بك من الكسل وسوء الكبر. رب أعوذ بك من النار وعذاب القبر',
    'translation': 'اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور',
    'time': 'ذكر الصباح'
  }
    ],
    'evening': [
      {
        'title': 'الاستعاذة بكلمات الله',
        'arabic': 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ',
        'translation': 'أعوذ بكلمات الله التامات من شر ما خلق',
        'time': 'يُقال في المساء للحماية من الشر'
      },
      {
        'title': 'الاستعاذة بكلمات الله',
    'arabic': 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ',
    'translation': 'أعوذ بكلمات الله التامات من شر ما خلق',
    'time': 'يُقال في المساء للحماية من الشر'
  },
  {
    'title': 'أعوذ بكلمات الله',
    'arabic': 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ',
    'translation': 'أعوذ بكلمات الله التامات من شر ما خلق',
    'time': 'ثلاث مرات في المساء للحماية من الشر'
  },
  {
    'title': 'اللهم بك أمسينا',
    'arabic': 'اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ',
    'translation': 'اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير',
    'time': 'ذكر المساء'
  },
  {
    'title': 'أذكار المساء من القرآن',
    'arabic': 'قراءة سورة الإخلاص والمعوذتين ثلاث مرات',
    'translation': 'سورة الإخلاص، سورة الفلق، سورة الناس',
    'time': 'من قالها حين يمسي كفته من كل شيء'
  },
  {
    'title': 'دعاء المساء',
    'arabic': 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحَدَهُ لَا شَرِيكَ لَهُ',
    'translation': 'أمسينا وأمسى الملك لله، والحمد لله لا إله إلا الله وحده لا شريك له',
    'time': 'يقال في المساء'
  },
  {
    'title': 'الاستغفار المسائي',
    'arabic': 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ',
    'translation': 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه',
    'time': 'يقال ثلاث مرات في المساء'
  },
  {
    'title': 'دعاة اخر'
    'arabic': 'اللهمَّ عافني في بدني، اللهم عافني في سمعي، اللهم عافني في بصري، لا إله إلا أنت. اللهم إني أعوذ بك من الكُـفرِ والفقر، وأعوذ بك من عذابِ القبر، لا إله إلا أنت.'
    'translation': 'اللهمَّ عافني في بدني، اللهم عافني في سمعي، اللهم عافني في بصري، لا إله إلا أنت. اللهم إني أعوذ بك من الكُـفرِ والفقر، وأعوذ بك من عذابِ القبر، لا إله إلا أنت.'
    'time' :'لة اجر كبير وعظيم وهو شكر للة '
  },
  {
    'title': 'حفظ الله لك المساء',
    'arabic': 'اللَّهُمَّ إِنِّي أَسْأَلُكَ عَفْوَ وَعَافِيَةً فِي الدُّنْيَا وَالْآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي',
    'translation': 'اللهم إني أسألك عفو وعافية في الدنيا والآخرة، اللهم إني أسألك العفو والعافية في ديني ودنياي وأهلي ومالي',
    'time': 'يقال في المساء'
  },
  {
    'title': 'تسبيح لة اجر عظيم',
    'arabic': 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ عَدَدَ خَلْقِهِ وَرِضَا نَفْسِهِ وَزِنَةَ عَرْشِهِ وَمِدَادَ كَلِمَاتِهِ',
    'translation': 'سبحان الله وبحمده عدد خلقه ورضا نفسه وزنة عرشه ومداد كلماته',
    'time': 'يقال ثلاث مرات في المساء'
  },
  {
    'title': 'دعاء المساء',
    'arabic': 'اللَّهُمَّ إِنِّي أَسْأَلُكَ فِعْلَ الْخَيْرَاتِ وَتَرْكَ الْمُنْكَرَاتِ وَحُبَّ الْمَسَاكِينِ وَأَنْ تَغْفِرَ لِي وَتَرْحَمَنِي',
    'translation': 'اللهم إني أسألك فعل الخيرات وترك المنكرات وحب المساكين وأن تغفر لي وترحمني',
    'time': 'يقال في المساء'
  },
  {
    'title': 'ذكر آخر',
    'arabic': 'لَا إِلَهَ إِلَّا اللَّهُ وَحَدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    'translation': 'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير',
    'time': 'يقال عشر مرات في المساء'
      },
    ],
    'afterPrayer': [
      {
        'title': 'الاستغفار',
    'arabic': 'أستغفر الله',
    'translation': 'أستغفر الله',
    'time': 'تقال ثلاث مرات'
  },
  {
    'title': 'التحية',
    'arabic': 'اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام',
    'translation': 'اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام',
    'time': 'مرة واحدة'
  },
  {
    'title': 'التوحيد',
    'arabic': 'لا اله الا الله وحده لا شريك له ؛له الملك وله الحمد ؛وهو علي كل شي قدير؛لا حول ولا قوة الا بالله؛لا اله الا الله؛ولا نعبد الا اياه ؛له النعمه وله الفضل وله الثناء الحسن ؛لا الة الا الله مخلصين له الدين ولو كره الكافرون',
    'translation': 'لا اله الا الله وحده لا شريك له ؛له الملك وله الحمد ؛وهو علي كل شي قدير؛لا حول ولا قوة الا بالله؛لا اله الا الله؛ولا نعبد الا اياه ؛له النعمه وله الفضل وله الثناء الحسن ؛لا الة الا الله مخلصين له الدين ولو كره الكافرون',
    'time': 'مرة واحدة'
  },
  {
    'title': 'شهادة التوحيد',
    'arabic': 'الله لا إله إلا هو وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير',
    'translation': 'الله لا إله إلا هو وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير',
    'time': 'مرة واحدة كل صلاة ما عدا المغرب والفجر تقال عشر مرات'
  },
  {
    'title': 'سور قرآنية',
    'arabic': 'سورة الإخلاص وسورة الفلق وسورة الناس',
    'translation': 'سورة الإخلاص وسورة الفلق وسورة الناس',
    'time': 'تقال مرة بعد كل صلاة ما عدا المغرب والفجر تقال ثلاث مرات'
  },
  {
    'title': 'آية الكرسي',
    'arabic': 'آية الكرسي',
    'translation': 'آية الكرسي',
    'time': 'من قرأها دبر كل صلاة لم يمنعه من دخول الجنة إلا الموت'
  },
  {
    'title': 'التسبيح',
    'arabic': 'سُبْحَانَ اللَّهِ',
    'translation': 'سبحان الله',
    'time': '33 مرة بعد كل صلاة'
  },
  {
    'title': 'الحمد لله',
    'arabic': 'الْحَمْدُ لِلَّهِ',
    'translation': 'الحمد لله',
    'time': '33 مرة بعد كل صلاة'
  },
  {
    'title': 'التكبير',
    'arabic': 'اللَّهُ أَكْبَرُ',
    'translation': 'الله أكبر',
    'time': '33 مرة بعد كل صلاة'
  },
  {
    'title': 'دعاء بعد الفجر',
    'arabic': 'اللهم إني أسألك علماً نافعاً ورزقاً طيباً وعملاً متقبلاً',
    'translation': 'اللهم إني أسألك علماً نافعاً ورزقاً طيباً وعملاً متقبلاً',
    'time': 'بعد صلاة الفجر فقط'
      },
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(20),
          child: Text(
            'الأذكار والتسابيح',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1E8449),
              fontFamily: 'Amiri',
            ),
            textAlign: TextAlign.center,
          ),
        ),
        
        // Category buttons
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildCategoryButton('morning', 'أذكار الصباح'),
              _buildCategoryButton('evening', 'أذكار المساء'),
              _buildCategoryButton('afterPrayer', 'بعد الصلاة'),
            ],
          ),
        ),
        
        SizedBox(height: 20),
        
        // Supplications list
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 20),
            itemCount: supplicationsData[currentCategory]!.length,
            itemBuilder: (context, index) {
              final supplication = supplicationsData[currentCategory]![index];
              return _buildSupplicationCard(supplication, index, context);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCategoryButton(String category, String title) {
    bool isActive = currentCategory == category;
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 5),
        child: ElevatedButton(
          onPressed: () {
            setState(() {
              currentCategory = category;
            });
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: isActive ? Color(0xFF1E8449) : Colors.grey[200],
            foregroundColor: isActive ? Colors.white : Color(0xFF1E8449),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
              side: BorderSide(color: Color(0xFF1E8449), width: 2),
            ),
            padding: EdgeInsets.symmetric(vertical: 12),
          ),
          child: Text(
            title,
            style: TextStyle(fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  Widget _buildSupplicationCard(Map<String, dynamic> supplication, int index, BuildContext context) {
    return Card(
      margin: EdgeInsets.only(bottom: 15),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        leading: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            color: Color(0xFF1E8449),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              '${index + 1}',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ),
        title: Text(
          supplication['title'],
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFF1E8449),
            fontFamily: 'Amiri',
          ),
        ),
        children: [
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Color(0xFFf0f8f0),
                    borderRadius: BorderRadius.circular(8),
                    border: Border(
                      right: BorderSide(color: Color(0xFF1E8449), width: 4),
                    ),
                  ),
                  child: Text(
                    supplication['arabic'],
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Amiri',
                      color: Color(0xFF2c3e50),
                      height: 1.8,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 15),
                Text(
                  supplication['time'],
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF95a5a6),
                    fontStyle: FontStyle.italic,
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border(
                      right: BorderSide(color: Color(0xFF27AE60), width: 3),
                    ),
                  ),
                  child: Text(
                    supplication['translation'],
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFF6c757d),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
} 