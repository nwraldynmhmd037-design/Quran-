name: merged_flutter_project
description: A new Flutter project.

publish_to: 'none' # Remove this line if you wish to publish to pub.dev

version: 1.0.0+1

environment:
sdk: ">=2.17.0 <3.0.0"

dependencies:
flutter:
sdk: flutter

cupertino_icons: ^1.0.2

dev_dependencies:
flutter_test:
sdk: flutter

flutter_lints: ^2.0.0

flutter:
uses-material-design: true

assets:
- assets/hafsData_v2-0.json
